<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{vatnumber}prestashop>vatnumber_b0b9a606a1c251323825ca45d40964dc'] = 'Aucun pays par défaut n\'est défini.';
$_MODULE['<{vatnumber}prestashop>vatnumber_cee549912e318726d2c4989bb507665f'] = 'Numéro de TVA Europeen';
$_MODULE['<{vatnumber}prestashop>vatnumber_9fa70ad6139f2a83269df74eb6747816'] = 'Activer la saisie du numéro de TVA intra-communautaire lors de la création de l\'adresse. Vous devez remplir le champ de la société pour permettre la saisie du numéro de TVA.';
$_MODULE['<{vatnumber}prestashop>vatnumber_162b29cf61678af2aaac37f440265c28'] = 'Votre pays a été mis à jour.';
$_MODULE['<{vatnumber}prestashop>vatnumber_0ca51bcd22e4d7b56b6f1d8a01cefc1f'] = 'La vérification du numéro de TVA avec le service web est maintenant activé.';
$_MODULE['<{vatnumber}prestashop>vatnumber_467c214bb76759108ece49873eda44e4'] = 'La vérification du numéro de TVA avec le service web est maintenant désactivé.';
$_MODULE['<{vatnumber}prestashop>vatnumber_038b34b36ec9eaf5f96d11e17f208f1b'] = 'Choisissez un pays';
$_MODULE['<{vatnumber}prestashop>vatnumber_f4f70727dc34561dfde1a3c529b6205c'] = 'Paramètres';
$_MODULE['<{vatnumber}prestashop>vatnumber_fa01fd956e87307bce4c90a0de9b0437'] = 'Pays du client';
$_MODULE['<{vatnumber}prestashop>vatnumber_7599b57d77ef1608b2f6da579794cc5b'] = 'Filtre les clients par pays.';
$_MODULE['<{vatnumber}prestashop>vatnumber_da0e4b4c2ffe78456b5a1d67fd854389'] = 'Activer la vérification du numéro de TVA via le service web';
$_MODULE['<{vatnumber}prestashop>vatnumber_59e1a8522a3bfca342cd7110b1d67b24'] = 'La vérification par le service web est lent. Activer cette option peut ralentir votre boutique.';
$_MODULE['<{vatnumber}prestashop>vatnumber_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activé';
$_MODULE['<{vatnumber}prestashop>vatnumber_b9f5c797ebbf55adccdd8539a65a0241'] = 'Désactivé';
$_MODULE['<{vatnumber}prestashop>vatnumber_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';


return $_MODULE;
