<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_e0de5a06213f21c55ca3283c009e0907'] = 'Bloc confidentialité des données clients';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_f192f208f0bc97af4c5213eee3e78793'] = 'Ajoute un bloc qui affiche un message concernant la confidentialité des données clients.';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Configuration mise à jour';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_fb32badede7c8613fddb8502d847c18b'] = 'Veuillez accepter nos conditions concernant la confidentialité des données clients, en cochant la case ci-dessous.';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_f4f70727dc34561dfde1a3c529b6205c'] = 'Paramètres';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_9a730b88a32c2932d18b8b6043cc4fb7'] = 'Afficher sur la page de création de compte';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activé';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_b9f5c797ebbf55adccdd8539a65a0241'] = 'Désactivé';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_88997f015a0ee407a5e797011ddd090d'] = 'Message sur la confidentialité des données pour la page de création de compte :';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_03e1a999dcdb904300ee1b1e767c83c9'] = 'Le message sera affiché sur le formulaire de création de compte.';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_b51d73fb490ad1245fa9b87042bbbbb7'] = 'Astuce : Si le message est trop long pour être affiché directement dans le formulaire, vous pouvez ajouter un lien vers l\'une de vos pages CMS et écrire le message sur cette page. Vous pouvez créer facilement des pages CMS via le menu "CMS" sous "Préférences".';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_67ebed7cf9667003ad2047609440513a'] = 'Afficher dans l\'espace client';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_fc67768369eadd8d4fb1e7839f5eae69'] = 'Message sur la confidentialité des données clients pour l\'espace client :';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_432d64c20d5d06378d96c247c3f358f4'] = 'Le message sur la confidentialité des données s\'affichera sur la page "Informations personnelles" du compte client.';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_de1126ae0ac67eb4fda28cfad8429c79'] = 'Astuce : Si le message est trop long pour être affiché directement sur la page, vous pouvez ajouter un lien vers l\'une de vos pages CMS et écrire le message sur cette page. Vous pouvez créer facilement des pages CMS via le menu "CMS" sous "Préférences".';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_fb0440f9ca32a8b49eded51b09e70821'] = 'Confidentialité des données clients';


return $_MODULE;
