<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{pscleaner}prestashop>pscleaner_e5a8af934462c05509c7de5f2f2c18a3'] = 'Nettoyage de PrestaShop';
$_MODULE['<{pscleaner}prestashop>pscleaner_4bcb9cc248b7f6c8dc7f5c323bde76de'] = 'Vérifie et répare les problèmes d\'intégrité fonctionnelle et supprime les données par défaut (produits, commandes, clients)';
$_MODULE['<{pscleaner}prestashop>pscleaner_752369f18aebeed9ae8384d8f1b5dc5e'] = 'Soyez très attentifs en utilisant cet outil, il n\'y a pas de retour en arrière possible !';
$_MODULE['<{pscleaner}prestashop>pscleaner_550b877b1a255ba717cfad4b82057731'] = 'Les requêtes suivantes ont permis de réparer certaines données:';
$_MODULE['<{pscleaner}prestashop>pscleaner_14a7ab23d566b4505d0c711338c19a08'] = '%d ligne(s)';
$_MODULE['<{pscleaner}prestashop>pscleaner_d1ff3c9d57acd4283d2793a36737479e'] = 'Il n\'y a rien qui nécessite d\'être réparé.';
$_MODULE['<{pscleaner}prestashop>pscleaner_53d097f11855337bb74f1444d6c47c99'] = 'Les requêtes suivantes ont permis de nettoyer votre base de données avec succès :';
$_MODULE['<{pscleaner}prestashop>pscleaner_098c3581a731f08d24311bbf515adbbb'] = 'Félicitations, tout est déjà en ordre!';
$_MODULE['<{pscleaner}prestashop>pscleaner_1bb7c5eb8682aeada82c407b40ec09c8'] = 'Catalogue supprimé';
$_MODULE['<{pscleaner}prestashop>pscleaner_ed6ecb7169d5476ef5251524bb17552a'] = 'Commandes et clients supprimés';
$_MODULE['<{pscleaner}prestashop>pscleaner_43364f357f96e8b70be4a44d44196807'] = 'Veuillez lire les mises en garde et cliquer sur le bouton pour les approuver.';
$_MODULE['<{pscleaner}prestashop>pscleaner_6c69628e1d57fa6e39162b039a82133b'] = 'Souhaitez-vous supprimer le catalogue produit ?';
$_MODULE['<{pscleaner}prestashop>pscleaner_6a68264705f23c8e3d505fd2c93a87ba'] = 'Souhaitez-vous supprimer commandes et clients ?';
$_MODULE['<{pscleaner}prestashop>pscleaner_c32516babc5b6c47eb8ce1bfc223253c'] = 'Catalogue';
$_MODULE['<{pscleaner}prestashop>pscleaner_da69e50b7440e12fe63287904819eaa3'] = 'J\'ai bien compris que tout le catalogue sera supprimé sans possibilité de retour en arrière : produits, caractéristiques, catégories, mot-clés, images, prix, fichiers joints, scènes, stocks, groupes et valeurs d\'attributs, fabricants, fournisseurs...';
$_MODULE['<{pscleaner}prestashop>pscleaner_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activé';
$_MODULE['<{pscleaner}prestashop>pscleaner_b9f5c797ebbf55adccdd8539a65a0241'] = 'Désactivé';
$_MODULE['<{pscleaner}prestashop>pscleaner_b2d7c99e984831bd36221baf34e9c26e'] = 'Supprimer le catalogue';
$_MODULE['<{pscleaner}prestashop>pscleaner_3300d0bf086fa38cf593fe4feff351f1'] = 'Commandes et clients';
$_MODULE['<{pscleaner}prestashop>pscleaner_a01f9a9a340c3c68a2dc4663f46d8637'] = 'J\'ai bien compris que tous les clients et commandes seront supprimés sans possibilité de retour en arrière : clients, paniers, commandes, connexions, visiteurs, stats...';
$_MODULE['<{pscleaner}prestashop>pscleaner_17ca7f22baf84821b6b73462c96fb1e3'] = 'Supprimer les commandes et clients';
$_MODULE['<{pscleaner}prestashop>pscleaner_3535aa31bd9005bde626ad4312b67d6b'] = 'Contraintes d\'intégrité fonctionnelle';
$_MODULE['<{pscleaner}prestashop>pscleaner_e84c6595e849214a70b35ed8f95d7d16'] = 'Vérifier et réparer';
$_MODULE['<{pscleaner}prestashop>pscleaner_ccc27439e3e08c444690af3bed668e2d'] = 'Nettoyage de la base de données';
$_MODULE['<{pscleaner}prestashop>pscleaner_39707b9cfefe433d64f695623d2d3fd7'] = 'Nettoyer et optimiser';


return $_MODULE;
