<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{feeder}prestashop>feeder_4dce2f12546b229088d3cc214c3c2f7d'] = 'Flux RSS de produits';
$_MODULE['<{feeder}prestashop>feeder_8e08defbab5b0cf81a6a6b8472b8feda'] = 'Créer un flux RSS avec vos derniers produits.';


return $_MODULE;
