<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blocksharefb}prestashop>blocksharefb_d5d8d3eab66d27ce437e210d0ce31fce'] = 'Bouton de Partage Facebook';
$_MODULE['<{blocksharefb}prestashop>blocksharefb_1c32abb67032ad28e8613bb67f6e9867'] = 'Permet à vos clients de partager vos produits ou contenus sur Facebook.';
$_MODULE['<{blocksharefb}prestashop>blocksharefb_353005a70db1e1dac3aadedec7596bd7'] = 'Partager sur Facebook !';


return $_MODULE;
