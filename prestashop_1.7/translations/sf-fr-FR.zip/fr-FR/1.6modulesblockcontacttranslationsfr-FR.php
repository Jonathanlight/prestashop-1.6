<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockcontact}prestashop>blockcontact_df8f3e2cd8d1acbb2d1aa46a45045ec5'] = 'Bloc contact';
$_MODULE['<{blockcontact}prestashop>blockcontact_318ed85b9852475f24127167815e85d9'] = 'Permet d\'ajouter des informations supplémentaires concernant le service client';
$_MODULE['<{blockcontact}prestashop>blockcontact_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Configuration mise à jour';
$_MODULE['<{blockcontact}prestashop>blockcontact_f4f70727dc34561dfde1a3c529b6205c'] = 'Paramètres';
$_MODULE['<{blockcontact}prestashop>blockcontact_90a613a116f4bd9390ff7379a114f8d7'] = 'Ce bloc affiche dans l\'en-tête votre numéro de téléphone ("Appelez-nous au") et un lien vers la page Contact ("Contactez-nous").';
$_MODULE['<{blockcontact}prestashop>blockcontact_5f6e75192756d3ad45cff4a1ee0a45ba'] = 'Vous pouvez modifier les adresses e-mail de votre page "Contact" dans la page "Contacts" du menu "Clients".';
$_MODULE['<{blockcontact}prestashop>blockcontact_ccffe09c1cd18f73ad1f76762fded097'] = 'Vous pouvez modifier les contacts de votre pied de page grâce au module "Bloc Informations de contact".';
$_MODULE['<{blockcontact}prestashop>blockcontact_7551cf1a985728fa2798db32c2ff7887'] = 'Numéro de téléphone';
$_MODULE['<{blockcontact}prestashop>blockcontact_ce8ae9da5b7cd6c3df2929543a9af92d'] = 'E-mail';
$_MODULE['<{blockcontact}prestashop>blockcontact_52e878b67e9d94d25425231162ef5133'] = 'Renseignez ici les informations relatives à votre service clients.';
$_MODULE['<{blockcontact}prestashop>blockcontact_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{blockcontact}prestashop>blockcontact_02d4482d332e1aef3437cd61c9bcc624'] = 'Contactez-nous';
$_MODULE['<{blockcontact}prestashop>blockcontact_75858d311c84e7ba706b69bea5c71d36'] = 'Notre service client est disponible 24h/24, 7j/7';
$_MODULE['<{blockcontact}prestashop>blockcontact_673ae02fffb72f0fe68a66f096a01347'] = 'Tél. :';
$_MODULE['<{blockcontact}prestashop>blockcontact_736c5a7e834b7021bfa97180fc453115'] = 'Contacter notre service client';
$_MODULE['<{blockcontact}prestashop>nav_02d4482d332e1aef3437cd61c9bcc624'] = 'Contactez-nous';
$_MODULE['<{blockcontact}prestashop>nav_320abee94a07e976991e4df0d4afb319'] = 'Appelez-nous au :';
$_MODULE['<{blockcontact}prestashop>blockcontact_9cfc9b74983d504ec71db33967591249'] = 'Contactez-nous';


return $_MODULE;
