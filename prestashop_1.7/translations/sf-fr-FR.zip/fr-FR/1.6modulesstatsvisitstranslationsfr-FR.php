<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{statsvisits}prestashop>statsvisits_504c16c26a96283f91fb46a69b7c8153'] = 'Visites et visiteurs';
$_MODULE['<{statsvisits}prestashop>statsvisits_432c3ab90b3af30ad318201ba09aa824'] = 'Ajoute des statistiques à propos de vos visites et visiteurs au tableau de bord des statistiques.';
$_MODULE['<{statsvisits}prestashop>statsvisits_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guide';
$_MODULE['<{statsvisits}prestashop>statsvisits_ffbee337f031c2282b311bac40bc8bb9'] = 'Déterminer l\'intérêt d\'une visite';
$_MODULE['<{statsvisits}prestashop>statsvisits_e90d50ca1e68dc66c97bd62929dcbaf1'] = 'Le graphique d\'évolution visiteurs ressemble fortement au graphique des visites, mais fournit des informations supplémentaires:';
$_MODULE['<{statsvisits}prestashop>statsvisits_e9849ece0b2ecf1eea74d92d492a47f2'] = 'Si c\'est le cas, alors félicitations, votre site est bien conçu et plaît indéniablement.';
$_MODULE['<{statsvisits}prestashop>statsvisits_c745121a98cf1d5b26bc5299d9880d5c'] = 'Dans le cas contraire, la conclusion n\'est pas si simple. Le problème peut être esthétique ou ergonomique, ou alors l\'offre insuffisante. Il se peut également que ces visiteurs soient arrivées là par erreur, sans intérêt particulier pour votre boutique ; ce phénomène arrive couramment avec les moteurs de recherche.';
$_MODULE['<{statsvisits}prestashop>statsvisits_9bf5a493522a65d550f096505874873b'] = 'Cette information est surtout qualitative : c\'est à vous de déterminer l\'intérêt d\'une visite sans suite.';
$_MODULE['<{statsvisits}prestashop>statsvisits_b8901fb7bbfaf9b0c4724343c7cd1f90'] = 'Une visite correspond au passage d\'un internaute sur votre boutique. Une seule visite est comptée pour toute la durée de sa session.';
$_MODULE['<{statsvisits}prestashop>statsvisits_f43a4cf6dcc4ec617d2296d03d26c90f'] = 'On appelle visiteur une personne inconnue - non inscrite ou non connectée - naviguant sur votre boutique. Un visiteur peut donc visiter votre boutique plusieurs fois.';
$_MODULE['<{statsvisits}prestashop>statsvisits_54067074d24489ddb5654bf46642cb85'] = 'Nombre total de visites';
$_MODULE['<{statsvisits}prestashop>statsvisits_23e640d55e56db79971918936e95bf9d'] = 'Nombre total de visiteurs';
$_MODULE['<{statsvisits}prestashop>statsvisits_998e4c5c80f27dec552e99dfed34889a'] = 'Export CSV';
$_MODULE['<{statsvisits}prestashop>statsvisits_39b960b0a5e2ebaaa638d946f1892050'] = 'Nombre de visites et visiteurs uniques';
$_MODULE['<{statsvisits}prestashop>statsvisits_d7e637a6e9ff116de2fa89551240a94d'] = 'Visites';
$_MODULE['<{statsvisits}prestashop>statsvisits_ae5d01b6efa819cc7a7c05a8c57fcc2c'] = 'Visiteurs';


return $_MODULE;
