<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{statslive}prestashop>statslive_fa55230e9791f2b71322869318a5f00f'] = 'Visiteurs en ligne';
$_MODULE['<{statslive}prestashop>statslive_abf306fd198ab007d480ed610a6690fb'] = 'Ajoute une liste de clients et visiteurs qui sont actuellement connecté, dans le tableau de bord des statistiques.';
$_MODULE['<{statslive}prestashop>statslive_85f955e33756b8f40ce35e5b277de5bc'] = 'Vous devez activer l\'option "Enregistrer les pages vues pour chaque client" du module "Récupération des données statistiques" (StatsData) pour pouvoir voir les pages que vos visiteurs sont en train de parcourir.';
$_MODULE['<{statslive}prestashop>statslive_f5ee3b50dba1fb98f1342a584e46cd30'] = 'Clients actuellement en ligne';
$_MODULE['<{statslive}prestashop>statslive_66c4c5112f455a19afde47829df363fa'] = 'Total :';
$_MODULE['<{statslive}prestashop>statslive_d37c2bf1bd3143847fca087b354f920e'] = 'ID client';
$_MODULE['<{statslive}prestashop>statslive_49ee3087348e8d44e1feda1917443987'] = 'Nom';
$_MODULE['<{statslive}prestashop>statslive_13aa8652e950bb7c4b9b213e6d8d0dc5'] = 'Page en cours';
$_MODULE['<{statslive}prestashop>statslive_9dd3bc54879dc9425d44de81f3d7dfdc'] = 'Afficher le profil de l\'utilisateur';
$_MODULE['<{statslive}prestashop>statslive_08448d43d8e4b39ad5126d4b06e2f3cc'] = 'Il n\'y a pas de client en ligne en ce moment.';
$_MODULE['<{statslive}prestashop>statslive_cf6377279146be659952cea754c558b1'] = 'Visiteurs actuellement en ligne';
$_MODULE['<{statslive}prestashop>statslive_f8cf0a1a6b03d2b01602992ea273134c'] = 'ID de l\'invité';
$_MODULE['<{statslive}prestashop>statslive_a12a3079e14ced46e69ba52b8a90b21a'] = 'IP';
$_MODULE['<{statslive}prestashop>statslive_bc5188ca43d423ba3730e4c030609d6e'] = 'Dernière activité';
$_MODULE['<{statslive}prestashop>statslive_b6f05e5ddde1ec63d992d61144452dfa'] = 'Origine';
$_MODULE['<{statslive}prestashop>statslive_ec0fc0100c4fc1ce4eea230c3dc10360'] = 'Indéfini';
$_MODULE['<{statslive}prestashop>statslive_6adf97f83acf6453d4a6a4b1070f3754'] = 'Aucun';
$_MODULE['<{statslive}prestashop>statslive_a55533db46597bee3cd16899c007257e'] = 'Il n\'y a aucun visiteur en ligne actuellement.';
$_MODULE['<{statslive}prestashop>statslive_24efa7ee4511563b16144f39706d594f'] = 'Avertissement';
$_MODULE['<{statslive}prestashop>statslive_e5900cd9ae26ca607f7cd497f114b9f9'] = 'Les connexions en provenance d\'adresses IP de maintenance sont exclues des statistiques des visiteurs.';
$_MODULE['<{statslive}prestashop>statslive_05b564d49dbd9049f0df80a45cfe7d1c'] = 'Ajouter ou supprimer une adresse IP.';


return $_MODULE;
