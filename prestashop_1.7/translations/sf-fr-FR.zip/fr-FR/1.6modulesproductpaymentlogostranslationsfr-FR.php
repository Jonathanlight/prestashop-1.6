<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_1056d03db619b016d8fc6b60d08ef488'] = 'Bloc logos des modules de paiement';
$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_88fd6d994459806f2dcb8999ac03c76e'] = 'Affiche sur la fiche produit les logos des solutions de paiement disponibles.';
$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_126b21ce46c39d12c24058791a236777'] = 'image non valable';
$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_df7859ac16e724c9b1fba0a364503d72'] = 'Une erreur s\'est produite lors de l\'envoi du fichier.';
$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_f4f70727dc34561dfde1a3c529b6205c'] = 'Paramètres';
$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_223795d3a336ef80c5b6a070ae4e0d2a'] = 'En-tête du bloc';
$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_c7dd01cfb61ff8c984c0aff44f6540e3'] = 'Vous pouvez choisir d\'ajouter un titre au-dessus des logos.';
$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_89ca5c48bbc6b7a648a5c1996767484c'] = 'Image';
$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_9ce38727cff004a058021a6c7351a74a'] = 'Lien de l\'image';
$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_826eeee52fe142372c3a2bc195eff911'] = 'Vous pouvez soit mettre votre propre image en ligne à l\'aide du formulaire ci-dessus, ou mettre un lien vers celle-ci grâce à l\'option "Lien de l\'image".';
$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';


return $_MODULE;
