<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{watermark}prestashop>watermark_ee20bb60493f049175fc10c35acd2272'] = 'Filigrane';
$_MODULE['<{watermark}prestashop>watermark_8d7c07bcea7e80d072308e4bd4cc37b0'] = 'Protégez vos images avec un filigrane';
$_MODULE['<{watermark}prestashop>watermark_69a1a3ad8dd5da6db3c4da838a0cf9c7'] = 'Êtes-vous certain de vouloir effacer vos données ?';
$_MODULE['<{watermark}prestashop>watermark_2d38fba67823b23e2d5c93b5b8a5d707'] = 'Un filigrane doit être enregistré pour que ce module fonctionne correctement.';
$_MODULE['<{watermark}prestashop>watermark_842262778d363362c95aa210c9752c25'] = 'L\'opacité est requise.';
$_MODULE['<{watermark}prestashop>watermark_9d1e7d4f41c6bcac92fa25f7f615c43e'] = 'L\'opacité n\'est pas dans l\'intervalle autorisé.';
$_MODULE['<{watermark}prestashop>watermark_d31c2d99614d8e16430d2d8c99c1f2b0'] = 'Alignement en Y requis.';
$_MODULE['<{watermark}prestashop>watermark_8fe9c39f4bf87082caabcf3650970c71'] = 'Valeur incorrecte pour l\'alignement en Y.';
$_MODULE['<{watermark}prestashop>watermark_c2cf8e33c907a4cc689881dc8fa571c2'] = 'Alignement en X requis.';
$_MODULE['<{watermark}prestashop>watermark_3a1f788dbe8957be92048606cf0d3fcb'] = 'Valeur incorrecte pour l\'alignement en X.';
$_MODULE['<{watermark}prestashop>watermark_a9cac4be0fa0b815376b96f49e1435d7'] = 'Au moins un type d\'image doit être sélectionné.';
$_MODULE['<{watermark}prestashop>watermark_b670770ad59c1f8e7fb65f276074172b'] = 'L\'image doit être au format GIF.';
$_MODULE['<{watermark}prestashop>watermark_130aab6764f25267c79cef371270eb2a'] = 'Une erreur est survenue lors du chargement du filigrane : %1$s à %2$s';
$_MODULE['<{watermark}prestashop>watermark_281bec6c0d3fed2b0f5839d1ee197a6e'] = 'Votre image filigrane n\'est pas au format GIF, merci de la convertir au lieu de la renommer.';
$_MODULE['<{watermark}prestashop>watermark_f4f70727dc34561dfde1a3c529b6205c'] = 'Paramètres';
$_MODULE['<{watermark}prestashop>watermark_cc99ba657a4a5ecf9d2d7cb974d25596'] = 'Une fois que vous avez configuré le module, vous devez régénérer les images à l\'aide de l\'outil disponible dans Préférences > Images. Notez que le filigrane sera intégré automatiquement aux nouvelles images que vous ajouterez.';
$_MODULE['<{watermark}prestashop>watermark_3dad9d209b698755340cd82c93fa299d'] = 'Fichier filigrane :';
$_MODULE['<{watermark}prestashop>watermark_ce4ca541df51a63fd8e78e0da29e1d44'] = 'Doit être au format GIF';
$_MODULE['<{watermark}prestashop>watermark_e61514a08d28de6659551c6dce37dbed'] = 'Opacité du filigrane (1-100)';
$_MODULE['<{watermark}prestashop>watermark_e4a60affa613d035430ab5b1f2c2dc40'] = 'Alignement en X :';
$_MODULE['<{watermark}prestashop>watermark_811882fecd5c7618d7099ebbd39ea254'] = 'Gauche';
$_MODULE['<{watermark}prestashop>watermark_4a548addbfb239bbd12f5afe11a4b6dc'] = 'Milieu';
$_MODULE['<{watermark}prestashop>watermark_7c4f29407893c334a6cb7a87bf045c0d'] = 'Droite';
$_MODULE['<{watermark}prestashop>watermark_7c60ca861e403259d8a41b5e6577788c'] = 'Alignement en Y :';
$_MODULE['<{watermark}prestashop>watermark_b28354b543375bfa94dabaeda722927f'] = 'Haut';
$_MODULE['<{watermark}prestashop>watermark_71f262d796bed1ab30e8a2d5a8ddee6f'] = 'Bas';
$_MODULE['<{watermark}prestashop>watermark_27bd5f34e4375356363346e90dbbe2ca'] = 'Choisissez les types d\'image pour lesquels le filigrane doit s\'appliquer :';
$_MODULE['<{watermark}prestashop>watermark_b48748047a9eed520aa26ae2a8b62905'] = 'Les clients connectés voient les images sans le filigrane';
$_MODULE['<{watermark}prestashop>watermark_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activé';
$_MODULE['<{watermark}prestashop>watermark_b9f5c797ebbf55adccdd8539a65a0241'] = 'Désactivé';
$_MODULE['<{watermark}prestashop>watermark_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';


return $_MODULE;
