<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{statsbestsuppliers}prestashop>statsbestsuppliers_b5f5c19c8729b639d4d2a256fcb01a10'] = 'Aucun résultat';
$_MODULE['<{statsbestsuppliers}prestashop>statsbestsuppliers_f5c493141bb4b2508c5938fd9353291a'] = 'Affichage de %1$s de %2$s';
$_MODULE['<{statsbestsuppliers}prestashop>statsbestsuppliers_49ee3087348e8d44e1feda1917443987'] = 'Nom';
$_MODULE['<{statsbestsuppliers}prestashop>statsbestsuppliers_2a0440eec72540c5b30d9199c01f348c'] = 'Quantité vendue';
$_MODULE['<{statsbestsuppliers}prestashop>statsbestsuppliers_ea067eb37801c5aab1a1c685eb97d601'] = 'Total payé';
$_MODULE['<{statsbestsuppliers}prestashop>statsbestsuppliers_cc3eb9ba7d0e236f33023a4744d0693a'] = 'Meilleurs fournisseurs';
$_MODULE['<{statsbestsuppliers}prestashop>statsbestsuppliers_37607fc64452028f4d484aa014071934'] = 'Ajoute une liste des meilleurs fournisseurs à votre tableau de bord des statistiques.';
$_MODULE['<{statsbestsuppliers}prestashop>statsbestsuppliers_998e4c5c80f27dec552e99dfed34889a'] = 'Export CSV';


return $_MODULE;
