<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{statsbestproducts}prestashop>statsbestproducts_8c4d7af5f578693f9a6cf391e912ee33'] = 'Aucun résultat';
$_MODULE['<{statsbestproducts}prestashop>statsbestproducts_f5c493141bb4b2508c5938fd9353291a'] = 'Affichage de %1$s de %2$s';
$_MODULE['<{statsbestproducts}prestashop>statsbestproducts_63d5049791d9d79d86e9a108b0a999ca'] = 'Référence';
$_MODULE['<{statsbestproducts}prestashop>statsbestproducts_49ee3087348e8d44e1feda1917443987'] = 'Nom';
$_MODULE['<{statsbestproducts}prestashop>statsbestproducts_2a0440eec72540c5b30d9199c01f348c'] = 'Quantité vendue';
$_MODULE['<{statsbestproducts}prestashop>statsbestproducts_6771f2d557a34bd89ea7abc92a0a069c'] = 'Prix de vente';
$_MODULE['<{statsbestproducts}prestashop>statsbestproducts_11ff9f68afb6b8b5b8eda218d7c83a65'] = 'Ventes';
$_MODULE['<{statsbestproducts}prestashop>statsbestproducts_25f4b31e8f3baec8b2f266e05af88943'] = 'Quantité vendue en une journée';
$_MODULE['<{statsbestproducts}prestashop>statsbestproducts_7664a37e0cc56aaf39aebf2edbd3f98e'] = 'Pages vues';
$_MODULE['<{statsbestproducts}prestashop>statsbestproducts_7bd5825a187064017975513b95d7f7de'] = 'Quantité disponible à la vente';
$_MODULE['<{statsbestproducts}prestashop>statsbestproducts_4d3d769b812b6faa6b76e1a8abaece2d'] = 'Activé';
$_MODULE['<{statsbestproducts}prestashop>statsbestproducts_950cf49f8ca529be64c924f16fcb5404'] = 'Meilleures ventes';
$_MODULE['<{statsbestproducts}prestashop>statsbestproducts_15429f69e40860368f6e113e4cba5601'] = 'Ajoute une liste des vos meilleures ventes dans le tableau de bord des statistiques.';
$_MODULE['<{statsbestproducts}prestashop>statsbestproducts_998e4c5c80f27dec552e99dfed34889a'] = 'Export CSV';


return $_MODULE;
