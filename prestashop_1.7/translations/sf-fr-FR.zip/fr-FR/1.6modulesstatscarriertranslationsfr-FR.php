<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{statscarrier}prestashop>statscarrier_2e6774abc54cb13cef2c5bfd5a2cb463'] = 'Répartition par transporteur';
$_MODULE['<{statscarrier}prestashop>statscarrier_b56f2e8e5f8694e8d09cbd8ec27c4e57'] = 'Ajoute un graphique affichant la répartition de chaque fournisseur dans le tableau de bord des statistiques.';
$_MODULE['<{statscarrier}prestashop>statscarrier_b1c94ca2fbc3e78fc30069c8d0f01680'] = 'Toutes';
$_MODULE['<{statscarrier}prestashop>statscarrier_d7778d0c64b6ba21494c97f77a66885a'] = 'Filtrer';
$_MODULE['<{statscarrier}prestashop>statscarrier_ff61af405aa570a9000e6ba2da39857a'] = 'Ce graphique représente la répartition des transporteurs pour vos commandes. Il est également possible de restreindre le champ de la répartition pour une commande en particulier.';
$_MODULE['<{statscarrier}prestashop>statscarrier_998e4c5c80f27dec552e99dfed34889a'] = 'Export CSV';
$_MODULE['<{statscarrier}prestashop>statscarrier_ae916988f1944283efa2968808a71287'] = 'Aucune commande valide pour cette période.';
$_MODULE['<{statscarrier}prestashop>statscarrier_d5b9d0daaf017332f1f8188ab2a3f802'] = 'Pourcentage de commandes par transporteur.';


return $_MODULE;
