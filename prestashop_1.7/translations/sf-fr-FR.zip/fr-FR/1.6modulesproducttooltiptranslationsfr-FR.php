<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{producttooltip}prestashop>producttooltip_4776f7eb5998034f7bbc63b6457d1ff4'] = 'Infobulles produit';
$_MODULE['<{producttooltip}prestashop>producttooltip_0406dc99f3d31535975fdddf6f4ae4d3'] = 'Affiche des informations sur la fiche produit : nombre de gens actuellement en train de la parcourir, dernière fois que le produit a été vendu, et dernière qu\'il a été ajouté à un panier.';
$_MODULE['<{producttooltip}prestashop>producttooltip_c888438d14855d7d96a2724ee9c306bd'] = 'Mise à jour réussie';
$_MODULE['<{producttooltip}prestashop>producttooltip_f4f70727dc34561dfde1a3c529b6205c'] = 'Paramètres';
$_MODULE['<{producttooltip}prestashop>producttooltip_6a3f9bbed911bae4ffe5ab84294d7b9f'] = 'Nombre de visiteurs';
$_MODULE['<{producttooltip}prestashop>producttooltip_5c65d0f105e43f5186c1275fb83a661a'] = 'Affiche le nombre de personnes qui consultent la fiche produit à l\'instant présent.';
$_MODULE['<{producttooltip}prestashop>producttooltip_6ce86506e83863b6414e760c8406e156'] = 'Si vous activez l\'option ci-dessus, vous devez en premier lieu activer la première option ("Enregistrer les pages vues pour chaque client") dans le module "Exploration de données pour les statistiques" (StatsData).';
$_MODULE['<{producttooltip}prestashop>producttooltip_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activé';
$_MODULE['<{producttooltip}prestashop>producttooltip_b9f5c797ebbf55adccdd8539a65a0241'] = 'Désactivé';
$_MODULE['<{producttooltip}prestashop>producttooltip_18522b8438c82ae472267ff57e8db76f'] = 'Durée de la période';
$_MODULE['<{producttooltip}prestashop>producttooltip_3367d7aeafaae0cfdb8334d6e442a58f'] = 'Indiquez la durée de période de référence.';
$_MODULE['<{producttooltip}prestashop>producttooltip_946e06ba50194b981f04263795ed1433'] = 'Par exemple, si vous indiquez 30 minutes, le module affichera le nombre de visiteurs sur les 30 dernières minutes.';
$_MODULE['<{producttooltip}prestashop>producttooltip_640fd0cc0ffa0316ae087652871f4486'] = 'minutes';
$_MODULE['<{producttooltip}prestashop>producttooltip_788b212e2524ec85463d68861342693c'] = 'Date de la dernière commande';
$_MODULE['<{producttooltip}prestashop>producttooltip_43e5b083da426132daf3a9fe05362da3'] = 'Affiche la date de la dernière commande de ce produit.';
$_MODULE['<{producttooltip}prestashop>producttooltip_f6916943428105792f433c337f4e9522'] = 'Ajouté à un panier';
$_MODULE['<{producttooltip}prestashop>producttooltip_3829b2b4ac783c8e53a25f5cd007224b'] = 'Si le produit n\'a pas encore été commandé, affiche la dernière fois qu\'il a été ajouté au panier.';
$_MODULE['<{producttooltip}prestashop>producttooltip_7f2a0ec5efa8b7aaa2d814df0d18b722'] = 'Ne pas afficher les événements datant de plus de';
$_MODULE['<{producttooltip}prestashop>producttooltip_44fdec47036f482b68b748f9d786801b'] = 'jours';
$_MODULE['<{producttooltip}prestashop>producttooltip_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{producttooltip}prestashop>producttooltip_265e0fd0901e35cae9978e2319b6c32e'] = '%d personne regarde actuellement ce produit.';
$_MODULE['<{producttooltip}prestashop>producttooltip_858d0bcd440ff0d1cc1e6bd53d4fe9f6'] = '%d personnes consultent actuellement ce produit.';
$_MODULE['<{producttooltip}prestashop>producttooltip_b2ccdeedefb87a6f4c52b0926b030d65'] = 'Dernière fois que ce produit a été acheté : ';
$_MODULE['<{producttooltip}prestashop>producttooltip_f934c297c7d902f5871edb4a12acbb84'] = 'Dernière fois que ce produit a été ajouté à un panier : ';


return $_MODULE;
